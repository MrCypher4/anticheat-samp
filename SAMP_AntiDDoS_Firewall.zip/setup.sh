#!/bin/bash
echo "=== Setting up Ultra Firewall for SAMP VPS ==="
apt update && apt upgrade -y
apt install -y iptables-persistent ufw fail2ban
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
iptables-restore < firewall.rules
netfilter-persistent save
cp sysctl.conf /etc/sysctl.conf
sysctl -p
cp -r fail2ban/* /etc/fail2ban/
systemctl restart fail2ban
bash ufw-rules.sh
echo "=== Firewall and Protections Installed Successfully ==="
